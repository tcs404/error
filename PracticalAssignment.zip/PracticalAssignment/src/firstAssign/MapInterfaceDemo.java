package firstAssign;
import java.util.HashMap;
import java.util.Map;
public class MapInterfaceDemo {
public static <K, V> Map<K, V>copyMap(Map<K, V> original)
		{
		Map<K, V> second_map = new HashMap<>();
		// using putAll method to copy from original Map to second_map
		second_map.putAll(original);
		return second_map;
		}
		public static void main(String[] args) {
		Map<String, String> map=new HashMap<String, String>();
		map.put("1","VAISHNAVI");
		map.put( "2","RUPESH");
		map.put( "3","SHRADDHA");
		map.put("4","NIMISH");
		map.put( "5","VEDANT");
		System.out.println("HashMap:"+map);
		map.put("6", "SHUBHAM");
		System.out.println("After adding item HashMap:"+map);
		String removed_value = (String)map.remove("2");
		// Verifying the returned value
		System.out.println("Removed value is: "+ removed_value);
		// Displaying the new map
		System.out.println("New map is: "+ map);
		System.out.println("Is the key '2' present? " + map.containsKey("2"));
		// Checking for the key_element '5'
		System.out.println("Is the key '5' present? " + map.containsKey("5"));
		System.out.println("The Value is: " + map.get("1"));
		// Getting the value of 10
		System.out.println("The Value is: " + map.get("4"));
		Map<String, String> second_map = copyMap(map);
		System.out.println("original map:"+map);
		System.out.println("second map:"+second_map);
	}
}
