package firstAssign;
class Swap<E> 
	{
		
		@SuppressWarnings("hiding")
		public<E> void swap(E[] a,int i,int j)
		{
		E t=a[i];
		a[i]=a[j];
		a[j]=t;
		}
	}

	public class SwapDemo{
	public static void main(String[] args) {
		Integer[] inum={3,6,9,12,15};
		System.out.print("Array : \n");
		for(Integer i:inum)
		{
		System.out.println(i+"");
		}
		Swap<Integer> iobj=new Swap<Integer>();
		iobj.swap(inum,0,2);
		System.out.println("After Swapping : \n");
		for(Integer j:inum)
		System.out.println(j+"");

}}
