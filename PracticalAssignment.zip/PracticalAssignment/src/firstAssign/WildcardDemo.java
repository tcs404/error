package firstAssign;
class Wildcard <T extends Number>
{
T[] num;
Wildcard(T[] o)
{
num=o;
}
double average()
{
double sum=0.0;
for(int i=0;i<num.length;i++)
{
sum+=num[i].doubleValue();
}
return sum/num.length;
}
boolean sameAvg(Wildcard<?> ob)
{
if(average()==ob.average())
return true;
return false;
}
}

public class WildcardDemo {

	public static void main(String[] args) {
		Integer inum[]= {6,5,4,3,2};
		Wildcard<Integer> iob=new Wildcard<Integer> (inum);
		double v=iob.average();
		System.out.println("iob average is:"+v);
		Double dnum[]= {2.3,1.9,3.5,6.4,8.2};
		Wildcard<Double> dob=new Wildcard<Double> (dnum);
		double w=dob.average();
		System.out.println("dob average i:"+w);
		Float fnum[]= {1.0f,2.0f,3.0f,4.0f,5.0f};
		Wildcard<Float> fob=new Wildcard<Float> (fnum);
		double f=fob.average();
		System.out.println("fob average is:"+f);
		System.out.println("Averages of iob and dob");
		if(iob.sameAvg(dob))
		System.out.println("are the same");
		else
		System.out.println(" are different");
		System.out.println("Averages of iob and fob");
		if(iob.sameAvg(fob))
		System.out.println("are the same");
		else
		System.out.println(" are different");


	}

}
