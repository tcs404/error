package firstAssign;

import java.util.ArrayList;

public class LambdaExpressionDemo2 {

	public static void main(String[] args) {
		ArrayList<Integer> arrList = new ArrayList<Integer>();
        arrList.add(30);
        arrList.add(99);
        arrList.add(54);
        arrList.add(33);
        arrList.add(65);
        arrList.add(66);
        // Using lambda expression to print all elements
        arrList.forEach(a -> System.out.println(a));
        // Using lambda expression to print even elements
        System.out.println("Even numbers are:");
        arrList.forEach(a -> { if (a%2 == 0) System.out.println(a); });
     }
}
