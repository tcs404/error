package firstAssign;
interface Conversion1{
public float Conversion(float f);
}

public class FahrenheitToCelsius {

	public static void main(String[] args) {
	Conversion1 c1=(f)-> { return ((f-32))*5/9;	

	};
	System.out.println("Fahrenheit to Celsius temperature:"+c1.Conversion(50)+ "C");
}}
