package firstAssign;

class Calculator<T1 extends Number,T2 extends Number> 
{
	T1 a;
	T2 b;
	Calculator(T1 a,T2 b)
	{
	//a=n1;
		this.a=a;
		this.b=b;
	//b=n2;
	}
	public double addition()
	{
	return a.doubleValue()+b.doubleValue();
	}
	public double substraction()
	{
	return a.doubleValue()-b.doubleValue();
	}
	public double multiplication()
	{
	return a.doubleValue()*b.doubleValue();
	}
	public double division()
	{
	return a.doubleValue()/b.doubleValue();
	}
	
public class CalculatorDemo{
	public static void main(String[] args) {
		Calculator<Integer,Double> obj=new Calculator<Integer,Double> (40,30.5);
		System.out.println("Addition of Given Two Numbers:"+obj.addition());
		System.out.println("Substraction of Given Two Numbers:"+obj.substraction());
		System.out.println("Multiplication of Given Two Numbers:"+obj.multiplication());
		System.out.println("Division of Given Two Numbers:"+obj.division());

	}
	
}
}
