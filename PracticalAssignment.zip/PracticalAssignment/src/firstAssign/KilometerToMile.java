package firstAssign;
interface KilometerToMiles{
public double Conversion(double km);
}

public class KilometerToMile {

	public static void main(String[] args) {
		KilometerToMiles c1=(km)-> { return ( km * 0.621371);
		};
		System.out.println("Kilometers to Miles:"+c1.Conversion(200)+"miles");


	}

}
