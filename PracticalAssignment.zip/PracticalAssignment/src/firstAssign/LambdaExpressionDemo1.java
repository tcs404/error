package firstAssign;
interface Sayable{ 
public String say(String name); 
} 

public class LambdaExpressionDemo1 {

	public static void main(String[] args) {
		Sayable s1=(name)->{ 
			return "HELLO..!!"+name; 
			}; 
			System.out.println(s1.say("VAISHNAVI")); 
	}
}
