package firstAssign;

import java.util.ArrayList;
import java.util.ListIterator;

public class ListInterfaceDemo {

	public static void main(String[] args) {
		ArrayList<String> l1=new ArrayList<String>();
		l1.add("KASS");
		l1.add("VAJRAI");
		l1.add("EKIV");
		l1.add("SAJJANGAD");
		l1.add("CHAR BHINTI");
		System.out.println("Content of list are:");
		ListIterator<String> list=l1.listIterator();
		while(list.hasNext())
		{
			String element=list.next();
			System.out.println(element+" ");
		}
		System.out.println();
		System.out.println("Contents of list in reverse:");
		while(list.hasPrevious())
		{
			String element=list.previous();
			System.out.println(element+" ");
		}	
	}
}
