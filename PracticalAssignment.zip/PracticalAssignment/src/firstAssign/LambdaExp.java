package firstAssign;
interface Addable1{
	int add(int num1,int num2);	
}
public class LambdaExp {

	public static void main(String[] args) {
		Addable1 add1=(num1,num2)->(num1+num2);
		System.out.println(add1.add(36, 63));

	}

}
