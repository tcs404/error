package firstAssign;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.ListIterator;
import java.util.Set;

public class SetInterfaceDemo {

	public static void main(String[] args) {
		 Set<String> a1 = new HashSet<String>();
		 Set<String> a2 = new HashSet<String>();
		 a1.add("red");
		 a1.add("blue");
		 a1.add("green");
		 a1.add("yellow");
		 //add items
		 a1.add("black");
		 a2.addAll(a1);
		 a2.add("white");
		 a2.add("purple");
		 a2.size();
		 //display items
		 System.out.println("Elements are "+a1);
		 ArrayList<String> al=new ArrayList<String>();
		 for(String x:a2)
		 al.add(x);
		 ListIterator<String> list=al.listIterator();
		 while(list.hasNext())
		 {
			 String element=list.next();
			 System.out.println(element+" ");
 
		 }
		 //System.out.println();
		 System.out.println("Contents of list in reverse:");
		 while(list.hasPrevious())
		 {
			 String element=list.previous();
			 System.out.println(element+" ");
 
		 }
		 //removing items
		 a2.remove("purple");
		 System.out.println("After removing element " +a2);
		 //search items
		 System.out.println("Does the set contains 'purple'?\n"+a2.contains("purple"));
		 System.out.println("Does the set contains 'blue'?\n"+a2.contains("blue"));

    }

}


