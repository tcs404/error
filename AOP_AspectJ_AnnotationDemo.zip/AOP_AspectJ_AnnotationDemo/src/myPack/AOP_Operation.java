package myPack;
//AOP file
import java.util.logging.Logger;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.AfterThrowing;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;

@Aspect
public class AOP_Operation {
Logger log=Logger.getLogger("myLog");
@Pointcut("execution(* Operation.*(..))")
public void k1() {}//Point_cut name
@Before("k1()")//applying Point_cut on before advice
public void myadvice(JoinPoint jp)//it is advice(before advice)
{
System.out.println("\n-----------Additional concern 1----------\n");
log.info("User is in AOP_Operation class - "+log.getName());
}
@Pointcut("execution(* Operation.m*(..))")
public void k2() {}//Point_cut name
@After("k2()")//applying Point_cut on after advice
public void myadvice1(JoinPoint jp) {
	System.out.println("\n-----------Additional concern 2----------\n");
	log.info("Method Signature:" +jp.getSignature());	
	
}
@AfterReturning(pointcut = "k1()",returning="result")
public void myadvice2(JoinPoint jp,Object result)//it is advice (after returning advice)
{
	System.out.println("\n-----------Additional concern 3----------\n");
	log.info("Method Signature:" +jp.getSignature());
	System.out.println("Result in advice :"+result);
	System.out.println("End of after advice...");
}
@Pointcut("execution(* Operation.k*(..))")
public void k3() {}//point_cut name
@Around("k3()")
public Object myadvice3(ProceedingJoinPoint pjp) throws Throwable{
	System.out.println("\n-----------Additional concern 4<Before> calling actual method----------\n");
	Object obj=pjp.proceed(); 
	System.out.println("\n-----------Additional concern 4<After> calling actual method----------\n");
	return obj;
}
@AfterThrowing(pointcut="k1()",throwing="error")
public void myadvice4(JoinPoint jp,Throwable error)//it is advice
{
	System.out.println("\n-----------Additional concern 5----------\n");	
	System.out.println("Method Signature:" +jp.getSignature());
	System.out.println("Exception is :"+error);
	System.out.println("End of after throwing advice...");
}

}
