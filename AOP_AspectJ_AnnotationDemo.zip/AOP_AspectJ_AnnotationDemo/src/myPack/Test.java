package myPack;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Test {

	public static void main(String[] args) {
		ApplicationContext context =new ClassPathXmlApplicationContext("ApplicationContext.xml");
		 Operation e =(Operation) context.getBean("opBean");
		 System.out.println("Defining the aspects,advices and pointcuts in AOP file.");
		 e.msg();
		 System.out.println("\n Calling m...\n");
		 e.m();
		 System.out.println("\n Calling k...\n");
		 e.k();
		 System.out.println("\n Calling divide()\n");
		 try
		 {e.divide(10, 2);
		 e.divide(5, 0);
		 }
		 catch(Exception ex)
		 {
			 System.out.println(ex);
		 }
		((ClassPathXmlApplicationContext)context).close();

	}

}
