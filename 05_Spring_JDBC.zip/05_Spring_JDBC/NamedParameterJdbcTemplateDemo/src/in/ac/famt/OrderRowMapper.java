package in.ac.famt;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

public class OrderRowMapper implements RowMapper<OrderMst> {

	@Override
	public OrderMst mapRow(ResultSet arg0, int arg1) throws SQLException {
		// TODO Auto-generated method stub
		OrderMst ordObj = new OrderMst();
		ordObj.setOrderId(arg0.getInt("orderId"));
		ordObj.setSupplierNm(arg0.getString("supplierNm"));
		ordObj.setOrderAmt(arg0.getDouble("orderAmt"));
		return ordObj;
	}
}