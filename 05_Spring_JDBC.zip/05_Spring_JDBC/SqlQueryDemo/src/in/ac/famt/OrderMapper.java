package in.ac.famt;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Map;

import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.object.SqlQuery;

public class OrderMapper extends SqlQuery<OrderMst> implements RowMapper<OrderMst> {

	@Override
	public OrderMst mapRow(ResultSet rs, int arg1) throws SQLException {
		// TODO Auto-generated method stub
		OrderMst om = new OrderMst();
	    om.setOrderId(rs.getInt("orderId"));
	    om.setSupplierNm(rs.getString("supplierNm"));
	    om.setOrderAmt(rs.getDouble("orderAmt"));
		return om;
	}

	@Override
	protected RowMapper<OrderMst> newRowMapper(Object[] arg0, Map<?, ?> arg1) {
		// TODO Auto-generated method stub
		return new OrderMapper();
	}

}
