package in.ac.famt;

import java.util.List;
import javax.sql.DataSource;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Test {
	private static ApplicationContext appctx;
	
	public static void main(String[] args) {
	
		appctx = new ClassPathXmlApplicationContext("appctx.xml");
		OrderDAO od = (OrderDAO)appctx.getBean("orderDAOBean1");

		DataSource ds = (DataSource)appctx.getBean("ds");
		
		od.displayAllOrders();
		
		
		
	}
}