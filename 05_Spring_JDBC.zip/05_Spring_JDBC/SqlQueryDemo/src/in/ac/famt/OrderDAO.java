package in.ac.famt;

import java.util.List;
import javax.sql.DataSource;

import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.object.SqlQuery;

public class OrderDAO {
	NamedParameterJdbcTemplate namedParaJdbcTemp;
		
	public NamedParameterJdbcTemplate getNamedParaJdbcTemp() {
		return namedParaJdbcTemp;
	}

	public void setNamedParaJdbcTemp(NamedParameterJdbcTemplate namedParaJdbcTemp) {
		this.namedParaJdbcTemp = namedParaJdbcTemp;
	}

	public void displayAllOrders(DataSource ds) {
	      String sqlStr = "SELECT * FROM OrderMst";
	      SqlQuery<OrderMst> sqlQry = new OrderMapper();
	      
	      sqlQry.setDataSource(ds);
	      sqlQry.setSql(sqlStr);
	      List <OrderMst> orderList = sqlQry.execute();
	      
	      for(OrderMst ordM:orderList){  
				System.out.println(ordM);
			}
	     
	   }
}