package in.ac.famt;

import java.util.HashMap;
import java.util.Map;
import javax.sql.DataSource;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;

public class OrderDAO {
	DataSource dataSource;
	
	public OrderDAO() {
		super();
	}

	public OrderDAO(DataSource dataSource) {
		super();
		this.dataSource = dataSource;
	}

	public OrderMst executeStoreProc(Integer id) {
		SimpleJdbcCall jdbcCall =  new SimpleJdbcCall(dataSource);
		jdbcCall.withProcedureName("getOrderDtls");
		
		Map<String, Object> inParamMap = new HashMap<String, Object>();
		inParamMap.put("in_ordid", id);
		SqlParameterSource inParamSrc = new MapSqlParameterSource(inParamMap);
		
		Map<String, Object> result = jdbcCall.execute(inParamSrc);
		System.out.println(result);
		
		//creating object for printing same output
	    OrderMst ordM = new OrderMst();
	    ordM.setOrderId(id);
	    ordM.setSupplierNm((String) result.get("out_supnm"));
	    ordM.setOrderAmt((Double) result.get("out_ordamt"));
	    return ordM;
	}
}