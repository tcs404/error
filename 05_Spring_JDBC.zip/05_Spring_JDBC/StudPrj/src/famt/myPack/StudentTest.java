package famt.myPack;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class StudentTest {
	private static ApplicationContext ctx;
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ctx = new ClassPathXmlApplicationContext("Appctx.xml");
		Student s1 = (Student)ctx.getBean("studBean1");
		System.out.println(s1);
		s1.setMarks(90);
		System.out.println(s1);
		System.out.println(s1.getNm());
	}
}