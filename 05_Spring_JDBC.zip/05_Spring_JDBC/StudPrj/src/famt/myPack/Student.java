package famt.myPack;

public class Student {
	int rollNo;
	String nm;
	int marks;
	Address addr;
	
	public Student(int rollNo, String nm, int marks, Address addr) {
		super();
		this.rollNo = rollNo;
		this.nm = nm;
		this.marks = marks;
		this.addr = addr;
	}

	public int getRollNo() {
		return rollNo;
	}

	public void setRollNo(int rollNo) {
		this.rollNo = rollNo;
	}

	public String getNm() {
		return nm;
	}

	public void setNm(String nm) {
		this.nm = nm;
	}

	public int getMarks() {
		return marks;
	}

	public void setMarks(int marks) {
		this.marks = marks;
	}
	
	public Address getAddr() {
		return addr;
	}

	public void setAddr(Address addr) {
		this.addr = addr;
	}

	@Override
	public String toString() {
		return "Student [rollNo=" + rollNo + ", nm=" + nm + ", marks=" + marks + ", addr=" + addr + "]";
	}
}