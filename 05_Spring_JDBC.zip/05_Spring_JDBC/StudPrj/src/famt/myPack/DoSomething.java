package famt.myPack;

public class DoSomething {

}
