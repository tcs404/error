package in.ac.famt;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.ResultSetExtractor;

public class OrderDAO {
	DataSource dataSource;
	
	public void setDataSource(DataSource dataSource) {
		this.dataSource = dataSource;
	}
		
	public List<OrderMst> getOrders() {
		String sqlStr = "SELECT * FROM OrderMst";
		JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
		
		List <OrderMst> ordMst = jdbcTemplate.query(sqlStr, new ResultSetExtractor<List<OrderMst>>(){
			@Override  
		    public List<OrderMst> extractData(ResultSet rs) throws SQLException, DataAccessException {
				List<OrderMst> ordLst = new ArrayList<OrderMst>();
		        while(rs.next()){  
		        	OrderMst om = new OrderMst();
		        	om.setOrderId(rs.getInt("orderId"));
		        	om.setSupplierNm(rs.getString("supplierNm"));
		        	om.setOrderAmt(rs.getInt("orderAmt"));
		        	ordLst.add(om);
		        }  
		        return ordLst;  
		    }    	  
		});
		return ordMst;
	}    
}