package in.ac.famt;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

public class OrderMapper implements RowMapper<OrderMst> {

	@Override
	public OrderMst mapRow(ResultSet rs, int arg1) throws SQLException {
		// TODO Auto-generated method stub
		OrderMst om = new OrderMst();
	    om.setOrderId(rs.getInt("orderId"));
	    om.setSupplierNm(rs.getString("supplierNm"));
	    om.setOrderAmt(rs.getDouble("orderAmt"));
		return om;
	}

}
