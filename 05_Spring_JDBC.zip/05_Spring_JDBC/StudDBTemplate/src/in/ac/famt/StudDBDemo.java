package in.ac.famt;

import java.util.List;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class StudDBDemo {
	private static ApplicationContext apct;
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		apct = new ClassPathXmlApplicationContext("appctx.xml");
		StudDAO s1 = (StudDAO)apct.getBean("studBean1");

		StudentClass stud = new StudentClass ();
		stud.setRollNo(9);
		stud.setStudNm("Manoj");
		stud.setMarks(92);
		
		if(s1.saveStudInfo(stud) == 1) {
			System.out.println("Record Saved Successfully...");
		}
		else {
			System.out.println("ERROR!!! Record not Saved...");
		}
			 
		stud.setStudNm("AA Preetam S");
		stud.setMarks(95);
		int rowCnt = s1.updateStudInfo(stud);
		if( rowCnt > 0) {
			System.out.println(rowCnt + " Record/s Updated Successfully...");
		}
		else {
			System.out.println("ERROR!!! Record/s not Updated...");
		}
	
		stud.setRollNo(3);
		rowCnt = s1.deleteStudInfo(stud);
		if( rowCnt > 0 ) {
			System.out.println(rowCnt + " Record/s Deleted Successfully...");
		}
		else {
			System.out.println("ERROR!!! Record/s not Deleted...");
		}

		StudentClass stud1 = s1.findStudByRollNo(7);
		System.out.println(stud1);
		
		StudentClass stud2 = s1.findStudByRollNo1(7);
		System.out.println("Info - > " + stud2);
		
		
		List<StudentClass> studLst = s1.selectAll();
        for (StudentClass s: studLst) {
            System.out.println(s);
        }
        studLst.clear();
        studLst = s1.selectAllB();
        for (StudentClass s: studLst) {
            System.out.println(s);
        }
	}
}