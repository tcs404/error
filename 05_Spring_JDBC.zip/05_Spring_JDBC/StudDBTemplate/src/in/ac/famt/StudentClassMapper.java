package in.ac.famt;

import java.sql.ResultSet;
import java.sql.SQLException;
import org.springframework.jdbc.core.RowMapper;

public class StudentClassMapper implements RowMapper<StudentClass> {

	@Override
	public StudentClass mapRow(ResultSet arg0, int arg1) throws SQLException {
		// TODO Auto-generated method stub
		StudentClass stud = new StudentClass();
		stud.setRollNo(arg0.getInt("rollNo"));
		stud.setStudNm(arg0.getString("studNm"));
		stud.setMarks(arg0.getInt("marks"));
		return stud;
	}
}