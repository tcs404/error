package in.ac.famt;

public class StudentClass {
	int rollNo;
	String studNm;
	int marks;
	
	public StudentClass() {
		super();
	}

	public StudentClass(int rollNo, String studNm, int marks) {
		super();
		this.rollNo = rollNo;
		this.studNm = studNm;
		this.marks = marks;
	}

	public int getRollNo() {
		return rollNo;
	}

	public void setRollNo(int rollNo) {
		this.rollNo = rollNo;
	}

	public String getStudNm() {
		return studNm;
	}

	public void setStudNm(String studNm) {
		this.studNm = studNm;
	}

	public int getMarks() {
		return marks;
	}

	public void setMarks(int marks) {
		this.marks = marks;
	}

	@Override
	public String toString() {
		return "StudentDetails are - \nRrollNo=" + rollNo + 
				", \nName=" + studNm + ", \nMarks=" + marks;
	}	
}