package in.ac.famt;

import java.util.List;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;

public class StudDAO {
	JdbcTemplate jdbcTemplate;

	public JdbcTemplate getJdbcTemplate() {
		return jdbcTemplate;
	}

	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}
	
	public int saveStudInfo(StudentClass stud) {
		String sqlStr = "INSERT INTO studrecord VALUES(" + stud.getRollNo() +",'" + stud.getStudNm() + "'," + stud.getMarks() + ")";
		return jdbcTemplate.update(sqlStr);
	}
	
	public int updateStudInfo(StudentClass stud) {
		String sqlStr = "UPDATE studrecord SET studNm = " + "'" + stud.getStudNm() + "', marks = " + stud.getMarks() + " WHERE rollNo = " + stud.getRollNo();
		return jdbcTemplate.update(sqlStr);
	}
	
	public int deleteStudInfo(StudentClass stud) {
		String sqlStr = "DELETE FROM studrecord WHERE rollNo = " + stud.getRollNo();
		return jdbcTemplate.update(sqlStr);
	}
		
	public StudentClass findStudByRollNo(int pRollNo) {
		String sqlStr = "SELECT * FROM studrecord WHERE rollNo = " + pRollNo;
		StudentClass stud = jdbcTemplate.queryForObject(sqlStr, new BeanPropertyRowMapper<StudentClass>(StudentClass.class));
		return stud;
	}
	
	public StudentClass findStudByRollNo1(int pRollNo) {
		String sqlStr = "SELECT * FROM studrecord WHERE rollNo = " + pRollNo;
		return jdbcTemplate.queryForObject(sqlStr, (rs, rowNum) ->
        new StudentClass(
                rs.getInt("rollNo"),
                rs.getString("studNm"),
                rs.getInt("marks")
        ));
	}
	
	public List<StudentClass> selectAll() {
		String sqlStr = "SELECT * FROM studrecord";
		List<StudentClass> studLst = jdbcTemplate.query(sqlStr, new StudentClassMapper());
		return studLst;
	}
		
	public List<StudentClass> selectAllB() {
		String sqlStr = "SELECT * FROM studrecord";
		List<StudentClass> studLst = jdbcTemplate.query(sqlStr, new BeanPropertyRowMapper<StudentClass>(StudentClass.class));
		return studLst;
	}
}