package in.ac.famt;

import java.util.HashMap;
import java.util.Map;
import javax.sql.DataSource;
import org.springframework.jdbc.core.simple.SimpleJdbcInsert;

public class OrderDAO {
	DataSource dataSource;
	
	public void setDataSource(DataSource dataSource) {
		this.dataSource = dataSource;
	}
	
	public void insertOrder(OrderMst om) {
		SimpleJdbcInsert jdbcInsert = new SimpleJdbcInsert(dataSource).withTableName("ordermst");
		
		Map<String,Object> parameters = new HashMap<String,Object>();
	    parameters.put("orderId", om.getOrderId());
	    parameters.put("supplierNm", om.getSupplierNm());
	    parameters.put("orderAmt",om.getOrderAmt());
	    
	      
	    jdbcInsert.execute(parameters);
	    System.out.println("Record inserted sucessfully.");
	}    
}