package in.ac.famt;

import javax.sql.DataSource;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class OrderDemo {
	private static ApplicationContext appctx;
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		appctx = new ClassPathXmlApplicationContext("appctx.xml");
		OrderDAO od = (OrderDAO)appctx.getBean("orderDAOBean1");

		DataSource ds = (DataSource)appctx.getBean("ds");
		
		od.setDataSource(ds);
		OrderMst om = od.getOrder(5);
		System.out.println(om);
		om = od.getOrder(6);
		System.out.println(om);
		om = od.getOrder(7);
		System.out.println(om);
	}
}