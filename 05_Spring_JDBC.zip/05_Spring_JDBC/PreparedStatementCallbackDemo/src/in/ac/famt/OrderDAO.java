package in.ac.famt;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import javax.sql.DataSource;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementCallback;

public class OrderDAO {
	DataSource dataSource;
	
	public OrderDAO() {
		super();
	}

	public OrderDAO(DataSource dataSource) {
		super();
		this.dataSource = dataSource;
	}

	public void setDataSource(DataSource dataSource) {
		this.dataSource = dataSource;
	}
	
	public void saveOrder(OrderMst om) {
		JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
		String sqlStr = "INSERT INTO ordermst(orderId, supplierNm, orderAmt) VALUES (?, ?, ?)";
		
		jdbcTemplate.execute(sqlStr,new PreparedStatementCallback<Boolean>(){  
		    @Override  
		    public Boolean doInPreparedStatement(PreparedStatement ps) throws SQLException {  	              
		        ps.setInt(1,om.getOrderId());  
		        ps.setString(2,om.getSupplierNm());  
		        ps.setDouble(3,om.getOrderAmt());  
 
		        return ps.execute();  	              
		    }  
		});    
        System.out.println("Data inserted Successfully");
	}    
}