package myPack;

public class Student {
int roll_no;
String name;
int marks1;
int marks2;
int marks3;
public Student() {
}
public Student(int roll_no, String name, int marks1, int marks2, int marks3) {
	this.roll_no = roll_no;
	this.name = name;
	this.marks1 = marks1;
	this.marks2 = marks2;
	this.marks3 = marks3;
}
@Override
public String toString() {
	return "student [roll_no=" + roll_no + ", name=" + name + ", marks1=" + marks1 + ", marks2=" + marks2 + ", marks3="
			+ marks3 + "]";
}

}
