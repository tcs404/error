package myPack;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Test {

	public static void main(String[] args) {
		ApplicationContext context =new ClassPathXmlApplicationContext("AppConfig.xml");
        Student stud=(Student) context.getBean("studBean");
        StudOperation studOp=(StudOperation) context.getBean("studOpBean");
		System.out.println("Calculating Total Marks and Grade...");
		int totalMarks=studOp.totalMarks(stud);
		String grade=studOp.getGrade(totalMarks);
        System.out.println("\n Total Marks = " + totalMarks + " with grade "+grade);
        System.out.println("\n Marks1 = "+studOp.getMarks1(stud));
        System.out.println("\n Marks2 = "+studOp.getMarks2(stud));
        ((ClassPathXmlApplicationContext)context).close();
	}

}
