package myPack;

public class Movies {
	//table name-movieInfo
    //property name should be same as database table field name
	private int movieid;
	private String title;
	private String actor;
	public Movies() {
		
	}
	public Movies(int movieid, String title, String actor) {
		
		this.movieid = movieid;
		this.title = title;
		this.actor = actor;
	}
	public int getMovieid() {
		return movieid;
	}
	public void setMovieid(int movieid) {
		this.movieid = movieid;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getActor() {
		return actor;
	}
	public void setActor(String actor) {
		this.actor = actor;
	}
	@Override
	public String toString() {
		return "Movies [movieid=" + movieid + ", title=" + title + ", actor=" + actor + "]";
	}
	
	

}