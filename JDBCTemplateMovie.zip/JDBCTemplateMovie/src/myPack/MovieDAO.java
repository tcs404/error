package myPack;

import java.sql.CallableStatement;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.CallableStatementCallback;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementCallback;
import org.springframework.jdbc.core.ResultSetExtractor;
import org.springframework.jdbc.core.RowMapper;

public class MovieDAO {

	JdbcTemplate jdbcTemplate;

	public JdbcTemplate getJdbcTemplate() {
		return jdbcTemplate;
	}

	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}

	//insert query
	public int saveMovie(Movies m1) {
		String sqlStr= "INSERT INTO movieinfo VALUES("+m1.getMovieid() +",'" +m1.getTitle() +"','"+m1.getActor() +"')";
		return jdbcTemplate.update(sqlStr);
				
	}
	//update query
	public int updateMovie(Movies m2) {
		String sqlStr="UPDATE movieinfo SET title='"+ m2.getTitle()+"',actor='"+m2.getActor() +"' WHERE movieid="+ m2.getMovieid()+"";
		return jdbcTemplate.update(sqlStr);
	}
	//delete query
	public int deleteMovie(Movies m3) {
		String sqlStr="DELETE from movieinfo WHERE movieid="+ m3.getMovieid()+"";
		return jdbcTemplate.update(sqlStr);
	}
	//ROWMAPPER
	public List<Movies> getAllMoviesRowMapper(){
		String sqlStr="SELECT * FROM movieinfo";
		return jdbcTemplate.query(sqlStr, new RowMapper<Movies>() {

			@Override
			public Movies mapRow(ResultSet arg0, int arg1) throws SQLException {
				
				Movies movObj= new Movies();
				movObj.setMovieid(arg0.getInt(1));
				movObj.setTitle(arg0.getString(2));
				movObj.setActor(arg0.getString(3));
				
				return movObj;
			}
			
		});
			
	}
	//Query for multiple row using ResultSetExtractor interface (for retrieve all records)
	public List<Movies> getAllMoviesRSE(){
		String sqlStr="SELECT * FROM movieinfo";
		return jdbcTemplate.query(sqlStr,new ResultSetExtractor<List<Movies>>() {

			@Override
			public List<Movies> extractData(ResultSet rs) throws SQLException, DataAccessException {
				List<Movies> movList=new ArrayList<Movies>();
				while(rs.next()) {
					Movies mObj=new Movies();
					mObj.setMovieid(rs.getInt(1));
					mObj.setTitle(rs.getString(2));
					mObj.setActor(rs.getString(3));
					movList.add(mObj);
				}
				return movList;
			}	
		});
	}
	//Query for multiple row using BeanPropertyRowMapper
	public List<Movies> getAllMoviesBPRowMapper(){
		String sqlStr="SELECT *FROM movieinfo";
		return jdbcTemplate.query(sqlStr, new BeanPropertyRowMapper<Movies>(Movies.class));
	}
	
	//Query for multiple row using java-8 using Lambda Expression
	public List<Movies> getAllMoviesJava8LambdaExp() {
		String sqlStr="SELECT * FROM movieinfo";
		return jdbcTemplate.query(sqlStr,(rs,rowNum)-> new Movies(rs.getInt(1),rs.getString(2),rs.getString(3)));
	}
	//Query for multiple rows using queryForList() method
	
	  public List<Map<String,Object>> getAllMoviesinList(){
		String sqlStr="SELECT * FROM movieinfo";
		return jdbcTemplate.queryForList(sqlStr);
	  }
		
		//following code is used to process the individual record
		public List<Movies> getAllMoviesinList1(){
		String sqlStr="SELECT * FROM movieinfo";
		List<Map<String,Object>> movList = jdbcTemplate.queryForList(sqlStr);
		 List<Movies> movLst =new ArrayList<Movies>();
		 movList.forEach((movLt) -> 
		 {
			 int mid=(int)movLt.get("movieid");
			 String mt=(String)movLt.get("title");
			 String act=(String)movLt.get("actor");
			 Movies movie=new Movies(mid,mt,act);
			 movLst.add(movie);
		 });
		 return movLst;
		 
		 
	}
	
	
	//Query for single value using queryForObject() method
	public String getMovieByID(Movies m1) {
		String sqlStr="SELECT title FROM movieinfo WHERE movieid=? ";
		return jdbcTemplate.queryForObject(sqlStr,String.class,m1.getMovieid());
	}
	//prepared statement call back interface demonstration for insert record
	public Boolean saveMoviePS(Movies m1) {
		String sqlStr= "INSERT INTO movieinfo VALUES(?,?,?)";
		return jdbcTemplate.execute(sqlStr, new PreparedStatementCallback<Boolean>() {

			@Override
			public Boolean doInPreparedStatement(PreparedStatement ps) throws SQLException, DataAccessException {
				ps.setInt(1, m1.getMovieid());
				ps.setString(2,m1.getTitle());
				ps.setString(3,m1.getActor());
			   ps.execute();
				if(ps.getUpdateCount()==1) {
					return true;
				}
				else {
					return false;
				}
			}});
	}
	//Stored procedure to insert record
	public Boolean insertStoredProcedure(Movies m1) {
		String callSP="{call moviedb.insertStoredProcedure(?,?,?)}";
		return jdbcTemplate.execute(callSP,new CallableStatementCallback<Boolean>() {

			@Override
			public Boolean doInCallableStatement(CallableStatement callStmt) throws SQLException, DataAccessException {
				callStmt.setInt("mID", m1.getMovieid());
				callStmt.setString("mTitle",m1.getTitle());
				callStmt.setString("mActor", m1.getActor());
				return callStmt.execute();
			}});
	}
	//CallableStatementCallback interface demonstration for movie count with specific id
	public Boolean callCountProcedure(Movies m1) {
		String callStr="{call moviedb.movieLst(?,?,?)}";
		return jdbcTemplate.execute(callStr, new CallableStatementCallback<Boolean>() {

			@Override
			public Boolean doInCallableStatement(CallableStatement cs) throws SQLException, DataAccessException {
				cs.setInt("mvID",m1.getMovieid());
				cs.registerOutParameter("movCnt", Types.INTEGER);
				cs.execute();
				boolean hasResults=false;
				ResultSet rs=cs.getResultSet();
				while(rs.next()) {
					System.out.println("Total movies with id="+m1.getMovieid()+"are-"+rs.getInt(1));
					hasResults=true;
					}
				return hasResults;
			}
			
		});
	}
	
	
}

	

	

