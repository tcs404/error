package myPack;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Test {


	public static void main(String[] args) {
		ApplicationContext ctx =new ClassPathXmlApplicationContext("Appctx.xml");
		//insert student record
		MovieDAO md1=(MovieDAO)ctx.getBean("movieBean1");
		Movies mo1 = new Movies();
		mo1.setMovieid(109);
		mo1.setTitle("ABCD2");
		mo1.setActor("SHRADDHA KAPOOR");
		
		/*int noOfRowsAffected = md1.saveMovie(mo1);
		if(noOfRowsAffected !=0)
			System.out.println("Movie data inserted succefully");
		else
			System.out.println("Error in insert operation!");*/
		
		
		//update movie record
		/*MovieDAO md2=(MovieDAO)ctx.getBean("movieBean1");
		Movies mo2 = new Movies(102,"IRON MAN","PQR");
		int noOfRowsupdated = md2.updateMovie(mo2);
		if(noOfRowsupdated !=0)
			System.out.println("Movie data updated succefully");
		else
			System.out.println("Error in update operation!");*/
		
		//delete movie record
		/*MovieDAO md3=(MovieDAO)ctx.getBean("movieBean1");
		Movies mo3=new Movies();
		mo3.setMovieid(103);
		int noOfRowsDeleted=md3.deleteMovie(mo3);
		if(noOfRowsDeleted !=0)
			System.out.println("Movie data delete succefully");
		else
			System.out.println("Error in delete operation!");*/
		
	//RowMapper
		/*System.out.println("Details of all movies using RowMapper-");
		System.out.println(md1.getAllMoviesRowMapper());*/
		
		
		//ResultSetExtractor
		/*System.out.println("Details of all movies using ResultSetExtractor-");
		System.out.println(md1.getAllMoviesRSE());*/
		
		//Query for multiple row using BeanPropertyRowMapper
		/*System.out.println("Details of all movies using BeanPropertyRowMapper-");
		System.out.println(md1.getAllMoviesBPRowMapper());*/
		
		//Query for multiple row using java 8 using lambda Expression
				/*System.out.println("Details of all movies using java 8 using LambdaExpression-");
				System.out.println(md1.getAllMoviesJava8LambdaExp());*/
				
		//Query for multiple rows using queryForList() method	
				/*System.out.println("Details of all movies using queryForList() method-");
				System.out.println(md1.getAllMoviesinList());
				*/
		//Query for the individual record queryForList() method	
				System.out.println("Details of single movies using queryForList() method-");
				System.out.println(md1.getAllMoviesinList1());

				
	
		//Query for single value using queryForObject
		/*System.out.println("Details of single movies using queryForObject -");
		System.out.println(md1.getMovieByID(mo1));*/
		
		
		//prepared statement 
		/*if(md1.saveMoviePS(mo1))
			System.out.println("Movie data inserted successfully using prepared statement interface!");
		else
			System.out.println("Error in insert operation for PS!");*/
				
				
				
		//CallableStatementCallback interface demonstration for movie count with specific id
		/*if(md1.callCountProcedure(mo1))		
			System.out.println("Movie count with specific id");
		else
			System.out.println("Error");
		*/
		
		
		//Stored procedure to insert record
		/*String status=md1.insertStoredProcedure(mo1).toString();
		if(status=="false")
			System.out.println("Movie data inserted successfully!!");	
		else
			System.out.println("Error in insert operation!!");
		//md1.printMovieNames();
			
		//md1.callCountProcedure(mo1);*/
		((ClassPathXmlApplicationContext)ctx).close();
		
	}
}