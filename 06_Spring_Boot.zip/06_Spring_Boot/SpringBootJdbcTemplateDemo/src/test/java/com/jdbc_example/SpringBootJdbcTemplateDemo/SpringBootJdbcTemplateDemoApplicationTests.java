package com.jdbc_example.SpringBootJdbcTemplateDemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootJdbcTemplateDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
