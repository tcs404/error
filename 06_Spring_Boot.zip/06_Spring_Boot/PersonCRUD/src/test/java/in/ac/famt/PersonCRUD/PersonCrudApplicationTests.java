package in.ac.famt.PersonCRUD;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PersonCrudApplicationTests {

	@Test
	void contextLoads() {
	}

}
