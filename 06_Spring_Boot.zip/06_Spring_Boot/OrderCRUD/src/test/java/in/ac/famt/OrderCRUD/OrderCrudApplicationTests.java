package in.ac.famt.OrderCRUD;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OrderCrudApplicationTests {

	@Test
	void contextLoads() {
	}

}
