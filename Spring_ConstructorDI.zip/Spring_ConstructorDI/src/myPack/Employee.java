package myPack;

public class Employee {
int eid;
String ename;
String address;

public Employee() {
}

public Employee(int eid, String ename, String address) {
	this.eid = eid;
	this.ename = ename;
	this.address = address;
}

@Override
public String toString() {
	return "Employee [eid=" + eid + ", ename=" + ename + ", address=" + address + "]";
}


}
