package myPackCollectionDObj;

public class Answer {
	int id;
	String aName;
	String by;
	public Answer() {
	}
	public Answer(int id, String aName, String by) {
		this.id = id;
		this.aName = aName;
		this.by = by;
	}
	@Override
	public String toString() {
		return "Answer [id=" + id + ", aName=" + aName + ", by=" + by + "]";
	}
	
}
