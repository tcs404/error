package myPackDependentObj;

public class Address {
	String houseNo;
	String buildingName;
	String city;
	String District;
	int pincode;
	public Address() {
	}
	public Address(String houseNo, String buildingName, String city, String district, int pincode) {
		this.houseNo = houseNo;
		this.buildingName = buildingName;
		this.city = city;
		District = district;
		this.pincode = pincode;
	}
	@Override
	public String toString() {
		return "Address [houseNo=" + houseNo + ", buildingName=" + buildingName + ", city=" + city + ", District="
				+ District + ", pincode=" + pincode + "]";
	}
	
}
