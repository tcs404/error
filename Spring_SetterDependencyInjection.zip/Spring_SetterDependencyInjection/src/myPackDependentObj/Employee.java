//Employee.java
package myPackDependentObj;

public class Employee {
	int Id;
	String empName;
	Address address;
	public int getId() {
		return Id;
	}
	public void setId(int id) {
		Id = id;
	}
	public String getEmpName() {
		return empName;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	

	public Address getAddress() {
		return address;
	}
	public void setAddress(Address address) {
		this.address = address;
	}
	@Override
	public String toString() {
		return "Employee [Id=" + Id + ", empName=" + empName + ", address=" + address + "]";
	}
	
}
