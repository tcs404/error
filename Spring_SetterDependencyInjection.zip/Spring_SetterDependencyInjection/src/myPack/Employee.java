package myPack;

public class Employee {
	int Id;
	String empName;
	String City;
	public int getId() {
		return Id;
	}
	public void setId(int id) {
		Id = id;
	}
	public String getEmpName() {
		return empName;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	public String getCity() {
		return City;
	}
	public void setCity(String city) {
		City = city;
	}
	@Override
	public String toString() {
		return "Employee [Id=" + Id + ", empName=" + empName + ", City=" + City + "]";
	}
	
	

}
