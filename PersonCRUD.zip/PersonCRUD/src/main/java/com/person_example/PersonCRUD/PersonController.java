package com.person_example.PersonCRUD;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class PersonController {
@Autowired
PersonDAO service;
@GetMapping("/person/display")
public List<Person> displayAllPerson(){
	return service.displayAll();
	}
@GetMapping("/person/search/{pid}")
public Person displayAPersonInfo(@PathVariable int pid) {
	Person per=service.findPerson(pid);
	if(per==null)
	{
		throw new PersonNotFoundException("PersonId="+pid);
	}
	return per;
}
@PostMapping("/person/add")
public String createPerson(@RequestBody Person per)
{
	Person newPerson=service.savePerson(per);
	return "Data Saved for"+newPerson.getName();
}
@PatchMapping("/person/update")
public String updatePerson(@RequestBody Person per) {
	Person newPerson =service.updatePerson(per);
	if(newPerson==null)
	{
		throw new PersonNotFoundException("PersonId="+per.getId());
	}
	return "Data Updated for"+newPerson.getName();
}
@DeleteMapping("/person/delete/{pid}")
public Person deletePerson(@PathVariable int pid) {
	Person per=service.deletePersonById(pid);
	if(per==null)
	{
		throw new PersonNotFoundException("PersonId="+pid);
	}
	return per;
}
}
