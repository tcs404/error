package com.person_example.PersonCRUD;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PersonCrudApplicationTests {

	@Test
	void contextLoads() {
	}

}
