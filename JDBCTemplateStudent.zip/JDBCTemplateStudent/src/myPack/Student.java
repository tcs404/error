package myPack;


public class Student {
	//table name-studentInfo
	//property name should be same as database table field name
String stud_name;
int stud_rollNo;
String stud_class;
long stud_mobileNo;
public Student() {
}
public Student(String stud_name, int stud_rollNo, String stud_class, long stud_mobileNo) {
	this.stud_name = stud_name;
	this.stud_rollNo = stud_rollNo;
	this.stud_class = stud_class;
	this.stud_mobileNo = stud_mobileNo;
}
public String getStud_name() {
	return stud_name;
}
public void setStud_name(String stud_name) {
	this.stud_name = stud_name;
}
public int getStud_rollNo() {
	return stud_rollNo;
}
public void setStud_rollNo(int stud_rollNo) {
	this.stud_rollNo = stud_rollNo;
}
public String getStud_class() {
	return stud_class;
}
public void setStud_class(String stud_class) {
	this.stud_class = stud_class;
}
public long getStud_mobileNo() {
	return stud_mobileNo;
}
public void setStud_mobileNo(long stud_mobileNo) {
	this.stud_mobileNo = stud_mobileNo;
}
@Override
public String toString() {
	return "Student [stud_name=" + stud_name + ", stud_rollNo=" + stud_rollNo + ", stud_class=" + stud_class
			+ ", stud_mobileNo=" + stud_mobileNo + "]";
}


}
