package myPack;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Test {

	public static void main(String[] args) {
	ApplicationContext ctx =new ClassPathXmlApplicationContext("Appctx.xml");
	
	
		//a.insert student 
		StudentDAO s1=(StudentDAO)ctx.getBean("studentBean1");
		Student st1 = new Student();
		st1.setStud_name("SHRADDHA");
		st1.setStud_rollNo(1002);
		st1.setStud_class("FYMCA");
		
		st1.setStud_mobileNo(9767576110L);
		
		
		/*int noOfRowsAffected = s1.saveStudent(st1);
		if(noOfRowsAffected !=0)
			System.out.println("Student data inserted succefully");
		else
			System.out.println("Error in insert operation!");*/
	
	
	//b.update student
		/*StudentDAO s2=(StudentDAO)ctx.getBean("studentBean1");
		Student st2=new Student("ADITI",1005,"FYMCA",9881652355L);
		int noOfRowsUpdated = s2.updateStudent(st2);
		if(noOfRowsUpdated !=0)
			System.out.println("Student data update succefully");
		else
			System.out.println("Error in update operation!");*/
		
		//c.delete student
		/*StudentDAO s3=(StudentDAO)ctx.getBean("studentBean1");
		Student st3=new Student();
		st3.setStud_rollNo(1001);
		int noOfRowsDeleted=s3.deleteStudent(st3);
		if(noOfRowsDeleted !=0)
			System.out.println("Student data delete succefully");
		else
			System.out.println("Error in delete operation!");*/
			
		
		//k.select all records
		/*System.out.println("Details of all students using RowMapper-");
		System.out.println(s1.getAllStudentRowMapper());*/
	
		//Query for single value using queryForObject
		Student st5 = new Student();
		st5.setStud_rollNo(1009);
		System.out.println("Details of single movies using queryForObject -");
	      System.out.println(s1.getStudentByID(st5));
		((ClassPathXmlApplicationContext)ctx).close();
	}

}
