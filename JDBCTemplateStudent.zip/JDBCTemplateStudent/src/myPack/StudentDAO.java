package myPack;


import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

public class StudentDAO {
	JdbcTemplate jdbcTemplate;

	public JdbcTemplate getJdbcTemplate() {
		return jdbcTemplate;
	}

	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}
	//a.insert query
		public int saveStudent(Student s1) {
			String sqlStr= "INSERT INTO studentinfo VALUES('"+s1.getStud_name() +"'," +s1.getStud_rollNo() +",'"+s1.getStud_class() +"',"+ s1.getStud_mobileNo()+")";
			return jdbcTemplate.update(sqlStr);
					
		}
	//b.update query
		public int updateStudent(Student s2) {
			String sqlStr="UPDATE studentinfo SET stud_name='"+s2.getStud_name()+ "',stud_class='"+s2.getStud_class()+"',stud_mobileNo="+s2.getStud_mobileNo()+" WHERE stud_rollNo="+s2.getStud_rollNo()+"";
			return jdbcTemplate.update(sqlStr);	
		}
	//c.delete query
		public int deleteStudent(Student s3) {
			String sqlStr="DELETE from studentinfo WHERE stud_rollNo="+ s3.getStud_rollNo()+"";
			return jdbcTemplate.update(sqlStr);
		}
		//k.ROWMAPPER
		public List<Student> getAllStudentRowMapper(){
			String sqlStr="SELECT * FROM studentinfo";
			return jdbcTemplate.query(sqlStr, new RowMapper<Student>() {

				@Override
				public Student mapRow(ResultSet arg0, int arg1) throws SQLException {
					
					Student stdObj= new Student();
					stdObj.setStud_name(arg0.getString(1));
					stdObj.setStud_rollNo(arg0.getInt(2));
					stdObj.setStud_class(arg0.getString(3));
				    stdObj.setStud_mobileNo(arg0.getLong(4));
					return stdObj;
				}
			
			});
		}
			//Query for single value using queryForObject() method
			public String getStudentByID(Student s1) {
					String sqlStr="SELECT stud_name FROM studentinfo WHERE stud_rollNo=? ";
					return jdbcTemplate.queryForObject(sqlStr,String.class,s1.getStud_rollNo());
				}
	
}
